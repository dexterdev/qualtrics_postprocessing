import csv

desired_columns1 = ['xwindowsize','ywindowsize']

with open('ValenceArousal_DataCollection_test_February 5, 2023_18.16.csv', 'r') as input_file, open('extracted_data1.csv', 'w', newline='') as output_file:
    reader = csv.DictReader(input_file)
    writer = csv.DictWriter(output_file, fieldnames=desired_columns1)
    writer.writeheader()

    for row in reader:
        new_row = {column: row[column] for column in desired_columns1}
        writer.writerow(new_row)


desired_columns2 = []
for i in range(1, 96+1):
    desired_columns2.extend([f'label{i}name', f'label{i}x', f'label{i}y'])

with open('ValenceArousal_DataCollection_test_February 5, 2023_18.16.csv', 'r') as input_file, open('extracted_data2.csv', 'w', newline='') as output_file:
    reader = csv.DictReader(input_file)
    writer = csv.DictWriter(output_file, fieldnames=desired_columns2)
    writer.writeheader()

    for row in reader:
        new_row = {column: row[column] for column in desired_columns2}
        writer.writerow(new_row)

