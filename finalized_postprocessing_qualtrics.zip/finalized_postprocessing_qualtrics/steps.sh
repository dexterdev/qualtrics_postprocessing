python VA_to_extract_relevantcolumns.py
awk '!((NR==2)||(NR==3))' < extracted_data1.csv > extracted_data1_new.csv
grep -oh "\w*.jpg\w*" extracted_data2.csv > jpgs
python numbers_.py
#generates csv: ./OUT_csv.csv
#paste extracted_data1_new.csv OUT_csv.csv | column -s $'\t' -t > OUT_FINAL.csv
