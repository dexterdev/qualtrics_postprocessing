import csv
import numpy as np

def extract_numbers(filename):
    numbers = []
    with open(filename, "r") as file:
        reader = csv.reader(file)
        for row in reader:
            for element in row:
                try:
                    float_num = float(element)
                    if 67.0 <= float_num <= 1496.0:
                        numbers.append(float_num)
                except ValueError:
                    pass
    return numbers


numbers = extract_numbers("extracted_data2.csv")
#print(numbers)
#print(len(numbers))

# open file in read mode
with open("extracted_data2.csv", 'r') as fp:
    for count_rows, line in enumerate(fp):
        pass
print('Total Lines', count_rows + 1)

number_cols=20
number_rows=count_rows + 1 - 3
n=np.array(numbers)
n=np.reshape(n,(number_rows,number_cols*2))

print(n)
jpg_list=[]
with open('./jpgs','r') as jpg_files:
    for line in jpg_files:
        line = line.replace('\n','')
        jpg_list.append(line)
        print(line)  # The comma to suppress the extra new line char

print(jpg_list)
k=0
jpg_lis = [[0] * number_cols for i in range(number_rows)]
for i in range(number_rows) : 
    for j in range(number_cols) : 
        jpg_lis[i][j]=jpg_list[k]
        k=k+1
print(jpg_lis)  



import pandas as pd

df1 = pd.read_csv('./extracted_data1_new.csv')
print(df1)

label_names = []
for i in range(1, 20+1):
    label_names.extend([f'label{i}name'])
df2=pd.DataFrame(data=jpg_lis, columns=label_names)            # values   # 1st column as index  # 1st row as the column names    
print(df2)

column_names = []
for i in range(1, 20+1):
    column_names.extend([f'label{i}x', f'label{i}y'])

#df=pd.DataFrame(data=n[1:,1:], index=n[1:,0], columns=n[0,1:])            # values   # 1st column as index  # 1st row as the column names       
df3=pd.DataFrame(data=n, columns=column_names)            # values   # 1st column as index  # 1st row as the column names    
#df.rename(index={0: "x", 1: "y", 2: "z"})     
print(df3)     

df=pd.concat([df1, df2, df3], axis=1)
print(df)

df.to_csv('./OUT_FINAL.csv', index=False)

