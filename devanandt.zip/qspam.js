Qualtrics.SurveyEngine.addOnload(function()

								 {
var that = this;

	/*Place Your Javascript Below This Line*/
	
xwindowsize = window.innerWidth;
ywindowsize = window.innerHeight;
Qualtrics.SurveyEngine.setEmbeddedData("xwindowsize", xwindowsize);
Qualtrics.SurveyEngine.setEmbeddedData("ywindowsize", ywindowsize);
	
var objectsmovedtotal = 0;

//Number of labels to be presented
var labelnumber = Qualtrics.SurveyEngine.getEmbeddedData("labelnumber");


//////////////////////////////// Change variables BELOW this line /////////////////////////////////
	
//Pixel height of button at the bottom of the spatial arrangement slide
var buttonwindowheight = 2;

//Simultaneous presentation
	
//Number of columns in simultaneous presentation mode
var columns =5 ;

//Number of rows (automatically computed from number of columns)
if (Qualtrics.SurveyEngine.getEmbeddedData("selecting") == 2){
	var rows = Math.ceil((labelnumber-Qualtrics.SurveyEngine.getEmbeddedData("objectsselectedtotal"))/columns);
} else {
	var rows = Math.ceil(Qualtrics.SurveyEngine.getEmbeddedData("objectsselectedtotal")/columns);
}
	
//Shortened instructions throughout spatial arrangement
var continue1 = "Please examine the pictures. When you are finished CLICK HERE to continue";

//Shortened instructions throughout spatial arrangement 2
//Shortened instructions throughout spatial arrangement 2
var alertContent = "Next, according to your evaluation, all 20 images will appear on the screen. \n Take as much time as necessary to re-examine your assessment based on all photos. \n Change their location if needed"
		
//Shortened instructions throughout spatial arrangement 3
var continue2 = "I am finished";
	
//Sequential presentation

//Shortened instructions throughout spatial arrangement
var continuenext = "Take as much time as you need to examine the facial expressions in each image Evaluate the valance face conveys (positive or negative) and how emotionally aroused the person in the photo is. When you are finished CLICK HERE to continue "

//Shortened instructions throughout spatial arrangement 2
var continuefinal = "You will be given a chance to edit your choices next(if necessary). CLICK HERE to continue";

//For spatial arrangement slide with coordinate axes

//Distance between axis and boundary
var axisdistance = 25;

//Instructions for labelling of horizontal axis
var continue3 = "1) NOW, PLEASE USE THE INPUT WINDOW IN THE LOWER RIGHT CORNER TO LABEL X, THE HORIZONTAL AXIS.";
//<br>THE FURTHER TO THE RIGHT (LEFT) AN ITEM IS POSITIONED THE HIGHER (LOWER) THAT ITEM SCORES ON X; 2) THEN, CLICK HERE TO CONTINUE"

//Instructions for labelling of vertical  axis
var continue4 = "1) NOW, PLEASE USE THE INPUT WINDOW IN THE LOWER RIGHT CORNER TO LABEL Y, THE VERTICAL AXIS.";
//<br>THE FURTHER UP (DOWN) AN ITEM IS POSITIONED THE HIGHER (LOWER) THAT ITEM SCORES ON Y; 2) THEN, CLICK HERE TO CONTINUE"

//For spatial arrangement slide with coordinate circles
	
//Term that appears in the spatial arrangement slide's center
var centrallabel = "Morality";

//Number of circles around the slide's center
var circlenumber = 4;
	
//Line width of circles
var circlewidth = 1;	
	
//Radius increment (in pixel) from circle to circle (if you set this to 0, radius increment = distance from center to top / number of circles)
var radius = 0;
		
//////////////////////////////// Change variables ABOVE this line /////////////////////////////////

//Importing embedded data
var labelnumber = Qualtrics.SurveyEngine.getEmbeddedData("labelnumber");
var maxlabels =  Qualtrics.SurveyEngine.getEmbeddedData("maxlabels");
var wordsOrPictures = Qualtrics.SurveyEngine.getEmbeddedData("wordsOrPictures");
var blockOrSequence = Qualtrics.SurveyEngine.getEmbeddedData("blockOrSequence");
var selecting = Qualtrics.SurveyEngine.getEmbeddedData("selecting");
var marking = Qualtrics.SurveyEngine.getEmbeddedData("marking");
var boxwidth = Qualtrics.SurveyEngine.getEmbeddedData("boxwidth");
var boxheight = Qualtrics.SurveyEngine.getEmbeddedData("boxheight");
var boxbordersize = Qualtrics.SurveyEngine.getEmbeddedData("boxbordersize");
var horizontalspacing = Qualtrics.SurveyEngine.getEmbeddedData("horizontalspacing");
var verticalspacing = Qualtrics.SurveyEngine.getEmbeddedData("verticalspacing");
var link = Qualtrics.SurveyEngine.getEmbeddedData("pictureLink");

//Importing ONLY selected labels
if (selecting == 1){
	var inhalt = [];	
	for (var i = 0; i < maxlabels; i++){
		var currentnumber = i;
		currentnumber ++;
		if (Qualtrics.SurveyEngine.getEmbeddedData("label"+currentnumber+"name") != "leer" && Qualtrics.SurveyEngine.getEmbeddedData("label"+currentnumber+"selected") == 1 || Qualtrics.SurveyEngine.getEmbeddedData("label"+currentnumber+"selected") == "group1" || Qualtrics.SurveyEngine.getEmbeddedData("label"+currentnumber+"selected") == "group2") {
			inhalt.push({
				name: Qualtrics.SurveyEngine.getEmbeddedData("label"+currentnumber+"name"),
				input: Qualtrics.SurveyEngine.getEmbeddedData("label"+currentnumber+"input"),
				selected: Qualtrics.SurveyEngine.getEmbeddedData("label"+currentnumber+"selected"),
				marked: Qualtrics.SurveyEngine.getEmbeddedData("label"+currentnumber+"marked"),
				labelnummer: i+1
				
			});
		}
	}
} else if (selecting == 2){
//Importing ONLY not de-selected labels
	var inhalt = [];	
	for (var i = 0; i < maxlabels; i++){
		var currentnumber = i;
		currentnumber ++;
		if (Qualtrics.SurveyEngine.getEmbeddedData("label"+currentnumber+"name") != "leer" && Qualtrics.SurveyEngine.getEmbeddedData("label"+currentnumber+"selected") != 0) {
			inhalt.push({
				name: Qualtrics.SurveyEngine.getEmbeddedData("label"+currentnumber+"name"),
				input: Qualtrics.SurveyEngine.getEmbeddedData("label"+currentnumber+"input"),
				selected: Qualtrics.SurveyEngine.getEmbeddedData("label"+currentnumber+"selected"),
				marked: Qualtrics.SurveyEngine.getEmbeddedData("label"+currentnumber+"marked"),
				labelnummer: i+1
				
			});
		}
	}
	
	
} else if (selecting == 0){
//Importing labels
	var inhalt = [];	
	for (var i = 0; i < maxlabels; i++){
		var currentnumber = i;
		currentnumber ++;
		if (Qualtrics.SurveyEngine.getEmbeddedData("label"+currentnumber+"name") != "leer" && Qualtrics.SurveyEngine.getEmbeddedData("label"+currentnumber+"selected") != 2) {
			inhalt.push({
				name: Qualtrics.SurveyEngine.getEmbeddedData("label"+currentnumber+"name"),
				input: Qualtrics.SurveyEngine.getEmbeddedData("label"+currentnumber+"input"),
				selected: Qualtrics.SurveyEngine.getEmbeddedData("label"+currentnumber+"selected"),
				marked: Qualtrics.SurveyEngine.getEmbeddedData("label"+currentnumber+"marked"),
				labelnummer: i+1
				
			});
		}
	}
	
		
//Debug	
}

	console.log("inhalt is: ");
	console.log(inhalt);
	//console.log(childs)

	
var buttonwindow = document.createElement("div")
	buttonwindow.id = "buttonwindow";
	buttonwindow.className = "buttonwindow";
	buttonwindow.style.width = xwindowsize + "px";
	buttonwindow.style.height = buttonwindowheight + "px";
	buttonwindow.style.border = 0;
	buttonwindow.style.position = "absolute";
	buttonwindow.style.bottom = "0px";
	
	
document.body.insertBefore(buttonwindow, document.body.firstChild);

	
var mainwindow = document.createElement("div")
	mainwindow.id = "mainwindow";
	mainwindow.className = "mainwindow";
	mainwindow.style.width = xwindowsize + "px";
	mainwindow.style.height = ywindowsize - buttonwindowheight - 3 + "px";
	mainwindow.style.border = 0;
	mainwindow.style.position = "absolute";
	mainwindow.style.marginBottom = "20px";
		 
document.body.insertBefore(mainwindow, document.body.firstChild);

var el = document.getElementById('body');



//Define axis function if applicable
if (Qualtrics.SurveyEngine.getEmbeddedData("background") == 1){
	function drawaxis(){	
	
// Axis labels
	
var xaxisl = document.createElement("div");
var x1 = document.createTextNode("Negative");
		
	xaxisl.className = "unselectable";	
xaxisl.style.position = "absolute";
xaxisl.style['z-index'] = 150;
xaxisl.style.zIndex = "150";
xaxisl.style.color = "black";
xaxisl.style.fontSize = "16px";
xaxisl.appendChild(x1);
	
xaxisl.style.top = ((ywindowsize - buttonwindowheight - 50)/2 -9) + "px";
xaxisl.style.left = "10px";
mainwindow.appendChild(xaxisl);

	
	
var xaxisr = document.createElement("div");
var x2 = document.createTextNode("Positive");

		xaxisr.className = "unselectable";
xaxisr.style.position = "absolute";
xaxisr.style['z-index'] = 150;
xaxisr.style.zIndex = "150";
xaxisr.style.color = "black";
xaxisr.style.fontSize = "16px";
xaxisr.appendChild(x2);
	
xaxisr.style.top = ((ywindowsize - buttonwindowheight - 50)/2 -9) + "px";
xaxisr.style.left = xwindowsize -130 + "px";
mainwindow.appendChild(xaxisr);	
	
	

var yaxisu = document.createElement("div");
var y1 = document.createTextNode("High Arousal");
	
		yaxisu.className = "unselectable";
yaxisu.style.position = "absolute";
yaxisu.style['z-index'] = 130;
yaxisu.style.zIndex = "130";
yaxisu.style.color = "black";
yaxisu.style.fontSize = "16px";
yaxisu.appendChild(y1);
	
yaxisu.style.top = "25px";
yaxisu.style.left = (xwindowsize/2) +5 + "px";
mainwindow.appendChild(yaxisu);	

	
		
var yaxisd = document.createElement("div");
var y2 = document.createTextNode("Low Arousal");
	
		yaxisd.className = "unselectable";
yaxisd.style.position = "absolute";
yaxisd.style['z-index'] = 110;
yaxisd.style.zIndex = "110";
yaxisd.style.color = "black";
yaxisd.style.fontSize = "16px";
yaxisd.appendChild(y2);
	
yaxisd.style.top = (ywindowsize - buttonwindowheight - 3) - 26 + "px";
yaxisd.style.left = (xwindowsize/2) - 5 + "px";
mainwindow.appendChild(yaxisd);

	


	
	
//Draw canvas

canvas = document.createElement('canvas');
canvas.width = xwindowsize;
canvas.height = ywindowsize - buttonwindowheight - 3;

canvas.style['z-index'] = 103;
canvas.style.position = 'absolute';
canvas.style.backgroundColor = 'white';
canvas.style.top = 0;
canvas.style.left = 0;

mainwindow.appendChild(canvas);

var ctx = canvas.getContext('2d');

ctx.strokeStyle="#000000";
	ctx.fillStyle="#000000";
	
	
	//x-axis
	
    ctx.beginPath();
    ctx.moveTo(axisdistance,((ywindowsize - buttonwindowheight - 3)/2));
    ctx.lineTo(axisdistance+10,((ywindowsize - buttonwindowheight - 3)/2)-5);
    ctx.lineTo(axisdistance+10,((ywindowsize - buttonwindowheight - 3)/2)+5);
	ctx.lineTo(axisdistance,((ywindowsize - buttonwindowheight - 3)/2));
    ctx.fill();
	
	ctx.fillRect(axisdistance+10,((ywindowsize - buttonwindowheight - 3)/2)-1,xwindowsize-(2*axisdistance)-20,2);
	
	ctx.beginPath();
    ctx.moveTo(xwindowsize-axisdistance,((ywindowsize - buttonwindowheight - 3)/2));
    ctx.lineTo(xwindowsize-axisdistance-10,((ywindowsize - buttonwindowheight - 3)/2)-5);
    ctx.lineTo(xwindowsize-axisdistance-10,((ywindowsize - buttonwindowheight - 3)/2)+5);
	ctx.lineTo(xwindowsize-axisdistance,((ywindowsize - buttonwindowheight - 3)/2));
    ctx.fill();
	
	//y-axis
	
	ctx.beginPath();
    ctx.moveTo((xwindowsize/2),axisdistance);
    ctx.lineTo((xwindowsize/2)+5,axisdistance+10);
    ctx.lineTo((xwindowsize/2)-5,axisdistance+10);
	ctx.lineTo((xwindowsize/2),axisdistance);
    ctx.fill();
	
	ctx.fillRect((xwindowsize/2)-1,axisdistance+10,2,(ywindowsize - buttonwindowheight - 3)-20-(2*axisdistance));
	
	ctx.beginPath();
    ctx.moveTo((xwindowsize/2),(ywindowsize - buttonwindowheight - 3)-axisdistance);
    ctx.lineTo((xwindowsize/2)+5,(ywindowsize - buttonwindowheight - 3)-10-axisdistance);
    ctx.lineTo((xwindowsize/2)-5,(ywindowsize - buttonwindowheight - 3)-10-axisdistance);
	ctx.lineTo((xwindowsize/2),(ywindowsize - buttonwindowheight - 3)-axisdistance);
    ctx.fill();
	
};	
	
// DONT DARW AT CREATION drawaxis();

}

//Define radial function if applicable

if (Qualtrics.SurveyEngine.getEmbeddedData("background") == 2){
if (radius == 0){
			radius = (ywindowsize - buttonwindowheight - 3 - circlewidth) / circlenumber / 2;
		}	
	
	function drawaxis(){	
	


	
	
//Draw canvas

canvas = document.createElement('canvas');
canvas.width = xwindowsize;
canvas.height = ywindowsize - buttonwindowheight - 3;

canvas.style['z-index'] = 103;
canvas.style.position = 'absolute';
canvas.style.backgroundColor = 'black';
canvas.style.top = 0;
canvas.style.left = 0;

mainwindow.appendChild(canvas);

		
		
var ctx = canvas.getContext('2d');

ctx.strokeStyle="#FFFFFF";
	ctx.fillStyle="#FFFFFF";
	
	//Circles
		
		for (var i = 1; i <= circlenumber; i++){		
	ctx.beginPath();
	ctx.arc((xwindowsize/2), ((ywindowsize - buttonwindowheight - 3)/2), radius*i, 0, Math.PI*2, true); 
	ctx.closePath();
	ctx.lineWidth = circlewidth;	
	ctx.stroke();
		}
		
//Central label
		
			var centralDiv = document.createElement("div");
	
			centralDiv.style.zIndex = 105;
	centralDiv.className = "Neutral";
	centralDiv.style.left = (xwindowsize/2)-(1/2)*(radius*Math.sqrt(2))+circlewidth/2+"px";
	centralDiv.style.top = ((ywindowsize - buttonwindowheight - 3)/2)-(1/2)*(radius*Math.sqrt(2))+circlewidth/2+"px";
		
		centralDiv.style.width = (radius*Math.sqrt(2))-circlewidth+"px";
		centralDiv.style.height = (radius*Math.sqrt(2))-circlewidth+"px";
	
		var para = document.createElement("p");
			para.className = "central";
		
			var node = document.createTextNode(centrallabel);
			para.appendChild(node);
			
			para.style.lineHeight = (radius*Math.sqrt(2))-circlewidth + "px";
		
			
			
	centralDiv.appendChild(para);
	
	
	mainwindow.appendChild(centralDiv);
		
	
	
	
};	
	
drawaxis();

}


var confirm = 0;	

	function confirmation(){
		
		alert(alertContent);//
		//if (Qualtrics.SurveyEngine.getEmbeddedData("background") == 1){
		//	continuebutton.onclick = function(){nameX();};///////////
	//	} else ////////////////////////
		///////////{
			continuebutton.onclick = function(){proceed();};
			                

/////////////////////////////////////////////////////////		
		var childs = document.getElementById("mainwindow").querySelectorAll(":scope > .box");
        for (let j = 0; j <= 3; j++) {
    
              console.log("ohmyg222")
              console.log(childs[j].id)
              //console.log(childs[0].class)
              console.log(childs[j].style.backgroundImage)
              console.log(childs[j].style.left)
              console.log(childs[j].style.top)
}
/////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////

//////////////////////////////////////////////////
//var images = document.getElementsByClassName('box');
// var l = images.length;
// for (var i = 0; i < l; i++) {
//     images[-1].parentNode.removeChild(images[-1]);
// }
///////////////////////////////////////////////////


//document.body.appendChild(childs[j-1]);



// p[class] {
//     background-image: childs[j].style.backgroundImage;
//     background-position: left: childs[j].style.left ; top: childs[j].style.top;
//     background-repeat: no-repeat;
// }
//////////////////////////////////////////////////////			
			
		//display();	
		//////////////////}	
		continuebutton.innerHTML = continue2; // I am finished
		confirm = 1;
// 		mainwindow.removeChild(mainwindow.lastElementChild);//////
		display2();//////////////
        rmdup();

	}
	
	function firstproceed(){
	
		mainwindow.innerHTML="";
		//Only for axis and radial version
		if (Qualtrics.SurveyEngine.getEmbeddedData("background") != 0){
			drawaxis();
		}	
		draginit();
		continuebutton.onclick = function(){addDiv();};
		continuebutton.innerHTML = continuenext;
		addDiv();



	}
	
	function proceed(){
		
		//Only for axis version
		//////////if (Qualtrics.SurveyEngine.getEmbeddedData("background") == 1){
			
			/////////if (document.getElementById("yaxislabel").value == "") {
			///////////	alert("Please fill in the blank!");
			///////return false;
			///////}
			
			////////Qualtrics.SurveyEngine.setEmbeddedData("yaxislabel", yaxislabel.value);}
		
		for (var i = 0; i < labelList.length; i++) {
			Qualtrics.SurveyEngine.setEmbeddedData("label" + labelList[i].labelnummer + "name", labelList[i].name);
			//Qualtrics.SurveyEngine.setEmbeddedData("label" + labelList[i].labelnummer + "x", labelList[i].xcoordinate + boxbordersize + (boxwidth * 1/2));
			//Qualtrics.SurveyEngine.setEmbeddedData("label" + labelList[i].labelnummer + "y", labelList[i].ycoordinate + boxbordersize + (boxheight * 1/2));
			//Qualtrics.SurveyEngine.setEmbeddedData("label" + labelList[i].labelnummer + "x", labelList[i].xcoordinate  + (boxwidth));
			//Qualtrics.SurveyEngine.setEmbeddedData("label" + labelList[i].labelnummer + "y", labelList[i].ycoordinate  + (boxheight));
			Qualtrics.SurveyEngine.setEmbeddedData("label" + labelList[i].labelnummer + "x", labelList[i].xcoordinate );
			Qualtrics.SurveyEngine.setEmbeddedData("label" + labelList[i].labelnummer + "y", labelList[i].ycoordinate );
			//Qualtrics.SurveyEngine.setEmbeddedData("label" + labelList[i].labelnummer + "x", labelList[i].xcoordinate);
			//Qualtrics.SurveyEngine.setEmbeddedData("label" + labelList[i].labelnummer + "y", labelList[i].ycoordinate);
		}
		
		
		Qualtrics.SurveyEngine.setEmbeddedData("xwindowsize", xwindowsize);
		Qualtrics.SurveyEngine.setEmbeddedData("ywindowsize", ywindowsize - buttonwindowheight - 3);
		
		//////////////////////////oldchild//////////////////
		mainwindow.innerHTML = "";
		oldchild=document.body.removeChild(document.getElementById("mainwindow"));
		document.body.removeChild(document.getElementById("buttonwindow"));
		
		that.clickNextButton();
		
	}
	
	function nameX(){
		document.onmousemove = null;
 		document.onmouseup = null;
		
		var xaxislabel = document.createElement("input");
		xaxislabel.setAttribute("type", "text");
		
		xaxislabel.id = "xaxislabel";
		xaxislabel.style.float = "right";
		xaxislabel.style.height = " 18px";
		xaxislabel.style.width = " 240px";
		
		buttonwindow.appendChild(xaxislabel);
		
		continuebutton.innerHTML = "<span style='padding: 0px; margin: 0px; font-size: 12px'>"+continue3+"</span>";
		continuebutton.onclick = function(){nameY();};
	}
	
	function nameY() {
		
		if (document.getElementById("xaxislabel").value == "") {
			 alert("Please fill in the blank!");
			return false;
		}
	
		Qualtrics.SurveyEngine.setEmbeddedData("xaxislabel", xaxislabel.value);
	
		var yaxislabel = document.createElement("input");
		yaxislabel.setAttribute("type", "text");
	
		yaxislabel.id = "yaxislabel";
		yaxislabel.style.float = "right";
		yaxislabel.style.height = " 18px";
		yaxislabel.style.width = " 240px";
		
		buttonwindow.replaceChild(yaxislabel, xaxislabel);
		
		continuebutton.innerHTML = "<span style='padding: 0px; margin: 0px; font-size: 12px'>"+continue4+"</span>";
		continuebutton.onclick = function(){proceed();};
		
	}
	
	var continuebutton = document.createElement("button");
	continuebutton.className = "button";
	
	if (blockOrSequence == 1){
	continuebutton.onclick = function(){confirmation();};
	//display2();/////////////
	}
	
	if (blockOrSequence == 2){
	continuebutton.onclick = function(){firstproceed();};
	console.log("ayyyyooooo")
	}
	

	
	continuebutton.style.align = "center";	
	continuebutton.innerHTML = continue1;
	continuebutton.style.zIndex = "200";
	
	if (blockOrSequence == 1){
	continuebutton.disabled = false;
	}
	
	if (blockOrSequence == 2){
	continuebutton.disabled = false;
	}
buttonwindow.appendChild(continuebutton);	

// Fisher-Yates shuffle

function shuffle(array) {
  var currentIndex = array.length, temporaryValue, randomIndex ;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
}

//Dragging


var dragobject = null;


var dragx = 0;
var dragy = 0;


var mousex = 0;
var mousey = 0;


function draginit() {


  document.onmousemove = drag;
  document.onmouseup = dragstop;
}

var foreground = 106;	
	
function dragstart(element) {


  
	dragobject = element;
  
	dragobject.style.zIndex = foreground;
	foreground ++;
	
  dragx = mousex - dragobject.offsetLeft;
  dragy = mousey - dragobject.offsetTop;
	
	oldmousex = mousex;
	
}

	
function dragstop() {
	
	//make sure coordinates are within borders
	if (labelList[dragobject.id].xcoordinate > xwindowsize - boxwidth - (boxbordersize*2)){
		labelList[dragobject.id].xcoordinate = xwindowsize - boxwidth - (boxbordersize*2)
		}else if (labelList[dragobject.id].xcoordinate < 0){
		labelList[dragobject.id].xcoordinate = 0
		}
		if (labelList[dragobject.id].ycoordinate >= ywindowsize - buttonwindowheight - boxheight - (boxbordersize*2)){
			labelList[dragobject.id].ycoordinate = ywindowsize - buttonwindowheight - boxheight - (boxbordersize*2)
		}else if(labelList[dragobject.id].ycoordinate <0){
			labelList[dragobject.id].ycoordinate =0}

			
		console.log(labelList[dragobject.id].xcoordinate);	
		console.log(labelList[dragobject.id].ycoordinate);	



			  				  
	if (blockOrSequence == 1){
	if (dragobject != null) {
	
	//Coloring
	if (dragobject.className == "box"){
		dragobject.className = "boxClicked";
	} else if (dragobject.className == "group1Box"){
		dragobject.className = "group1BoxClicked";
	} else if (dragobject.className == "group2Box"){
		dragobject.className = "group2BoxClicked";
	}
	
	
	
	if (labelList[dragobject.id].moved == false) {
		labelList[dragobject.id].moved = true;
		objectsmovedtotal = objectsmovedtotal + 1;
		}
	else {
		labelList[dragobject.id].moved = true;
	}
	
	if (objectsmovedtotal == labelList.length) {
		continuebutton.disabled = false;
	}
	}
	dragobject=null;
  
}
	
	
	if (blockOrSequence == 2){
	
	if (dragobject != null) {
		
		
	
	if (labelList[dragobject.id].moved == false) {
		if (mousex != oldmousex){
			dragobject.style.backgroundColor = "black";
		labelList[dragobject.id].moved = true;
		objectsmovedtotal = objectsmovedtotal + 1;
		continuebutton.disabled = false;
		}
		}
	else {
		labelList[dragobject.id].moved = true;
	}
	
	if (objectsmovedtotal == labelnumber && confirm == 0) {
		continuebutton.disabled = false;
		//addDiv2();//////////////////////

		continuebutton.innerHTML = continuefinal;
		continuebutton.onclick = function(){confirmation();};
                console.log("222222222222222222222222")
                //////display2();
	}
		
	}
	
	//Coloring
	
	if (marking == 1 || marking == 2 || marking == 3){
		if (dragobject.className == "box") {
			//console.log("Clicked label was gray.")
			dragobject.className = "group1Box";
			labelList[dragobject.id].selected = "group1";
		} else if (dragobject.className == "group1Box") {
			//console.log("Clicked label was blue.")
			dragobject.className = "box";
			labelList[dragobject.id].selected = "nogroup";
		} else {
			console.log("Error! Undefined group!")
		}
	}

	if (marking == 4 || marking == 5 || marking == 6){
		if (dragobject.className == "box") {
			//console.log("Clicked label was gray.")
			dragobject.className = "group1Box";
			labelList[dragobject.id].selected = "group1";
		} else if (dragobject.className == "group1Box") {
			//console.log("Clicked label was blue.")
			dragobject.className = "group2Box";
			labelList[dragobject.id].selected = "group2";
		} else if (dragobject.className == "group2Box") {
			//console.log("Clicked label was red.")
			dragobject.className = "box";
			labelList[dragobject.id].selected = "nogroup";
		} else {
			console.log("Error! Undefined group!")
		}
	}
	
	dragobject=null;
  
}
}
	

function drag(ereignis) {
	
	

  mousex = document.all ? window.event.clientX : ereignis.pageX;
  mousey = document.all ? window.event.clientY : ereignis.pageY;
	

	
//Limit draggable area	
	
  if(dragobject != null) {
	  
    if (labelList[dragobject.id].xcoordinate >= xwindowsize - boxwidth - (boxbordersize*2) && labelList[dragobject.id].ycoordinate >= ywindowsize - buttonwindowheight - boxheight - (boxbordersize*2)){
		dragobject.style.left = xwindowsize - boxwidth - (boxbordersize*2) + "px";
		dragobject.style.top = ywindowsize - buttonwindowheight - boxheight - (boxbordersize*2) + "px";
	} else if (labelList[dragobject.id].xcoordinate <= 0 && labelList[dragobject.id].ycoordinate <= 0){
		dragobject.style.left = 0 + "px";
		dragobject.style.top = 0 + "px";
	} else if (labelList[dragobject.id].xcoordinate >= xwindowsize - boxwidth - (boxbordersize*2) && labelList[dragobject.id].ycoordinate <= 0){
		dragobject.style.left = xwindowsize - boxwidth - (boxbordersize*2) + "px";
		dragobject.style.top = 0 + "px";
	} else if (labelList[dragobject.id].xcoordinate <= 0 && labelList[dragobject.id].ycoordinate >= ywindowsize - buttonwindowheight - boxheight - (boxbordersize*2)){
		dragobject.style.left = 0 + "px";
		dragobject.style.top = ywindowsize - buttonwindowheight - boxheight - (boxbordersize*2) + "px";
	} else if (labelList[dragobject.id].xcoordinate <= 0){
		dragobject.style.left = 0 + "px";
		dragobject.style.top = (mousey - dragy) + "px";
	} else if (labelList[dragobject.id].xcoordinate >= xwindowsize - boxwidth - (boxbordersize*2)){
		dragobject.style.left = xwindowsize - boxwidth - (boxbordersize*2) + "px";
		dragobject.style.top = (mousey - dragy) + "px";
	} else if (labelList[dragobject.id].ycoordinate <= 0) {
		dragobject.style.left = (mousex - dragx) + "px";
		dragobject.style.top = 0 + "px";
	} else if (labelList[dragobject.id].ycoordinate >= ywindowsize - buttonwindowheight - boxheight - (boxbordersize*2)) {
		dragobject.style.left = (mousex - dragx) + "px";
		dragobject.style.top = ywindowsize - buttonwindowheight - boxheight - (boxbordersize*2) + "px";
	} else {
		dragobject.style.left = (mousex - dragx) + "px";
		dragobject.style.top = (mousey - dragy) + "px";
		
		
	}
	
	labelList[dragobject.id].xcoordinate = mousex - dragx;
	labelList[dragobject.id].ycoordinate = mousey - dragy;
	
		}
	
	
	
	

  }





var labelList = [];



function addLabel(label, labelInput, labelSelected, x, y, nummer, labelMarked) {
	labelList.push({
		name: label,
		input: labelInput,
		selected: labelSelected,
		xcoordinate: x,
		ycoordinate: y,
		labelnummer: nummer,
		marked: labelMarked,
		moved: false
	});
}
	
			


shuffle(inhalt);




var zeile = 1;
var boxcounter = 0;

var startingpositionleft = 0;	
var startingpositiontop = (ywindowsize-buttonwindowheight-3)/2 - (boxheight*rows+verticalspacing*(rows-1))/2;

	
var j = startingpositionleft;
var k = startingpositiontop;
	
for (var i = 0; i < inhalt.length; i++) {
	addLabel(inhalt[i].name, inhalt[i].input, inhalt[i].selected, j, k, inhalt[i].labelnummer, inhalt[i].marked);
	boxcounter ++;
	console.log(boxcounter);
	j = j + boxwidth + horizontalspacing;
	
	if (boxcounter == columns) {
		j = startingpositionleft;
		k = k + boxheight + verticalspacing;
		boxcounter = 0;
		};
};



  





//Block presentation
	if (blockOrSequence == 1){


for (var i = 0; i < labelList.length; i++) {
	var newDiv = document.createElement("div");
	
	newDiv.id = i;
	

	
	//Color depending on group
	if (labelList[i].marked == 1){
		newDiv.className = "group1Box";
	} else if (labelList[i].marked == 2){
		newDiv.className = "group2Box";
	} else {
		newDiv.className = "box";
	}
	newDiv.style.left = labelList[i].xcoordinate+"px";
	newDiv.style.top = labelList[i].ycoordinate+"px";
	/*newDiv.style.left = 0+"px";*/
	/*newDiv.style.top = 0+"px";*/
	
	newDiv.onmousedown = function(){dragstart(this)};
	
	if (wordsOrPictures == 1){
		var para = document.createElement("p");
		para.className = "text";
		
		//Insert labelinput if applicable, otherwise use labelname
		if (Qualtrics.SurveyEngine.getEmbeddedData("generating") == 2){
			var node = document.createTextNode(labelList[i].input);
			para.appendChild(node);	
		} else {
			var node = document.createTextNode(labelList[i].name);
			para.appendChild(node);
		}
		
		//Insert labelinput if applicable
		if (Qualtrics.SurveyEngine.getEmbeddedData("generating") == 3){
			var node2 = document.createTextNode(labelList[i].input);
			var br = document.createElement("br");
			para.appendChild(br);
			para.appendChild(node2);
		}	
			
			
	newDiv.appendChild(para)
	}
	
	//Set pictures if applicable
	if (wordsOrPictures == 2){
	    // opacity 1 not here
		newDiv.style.backgroundImage = 'url("'+link+''+labelList[i].labelnummer+'.jpg")';
		
	newDiv.style.backgroundRepeat = 'no-repeat';
	newDiv.style.backgroundPosition = 'center';
	}	
	
	mainwindow.appendChild(newDiv);
};


draginit();
	}
	
//Sequential presentation	
	if (blockOrSequence == 2){
		
		
		for (var i = 0; i < labelList.length; i++) {
	var newDiv = document.createElement("div");
	
	 newDiv.id = i;
	

	
			newDiv.style.zIndex = foreground;
	//Color depending on group
	if (labelList[i].marked == 1){
		newDiv.className = "group1Box";
	} else if (labelList[i].marked == 2){
		newDiv.className = "group2Box";
	} else {
		newDiv.className = "box";
	}
	newDiv.style.left = labelList[i].xcoordinate+"px";
	newDiv.style.top = labelList[i].ycoordinate+"px";
	
	newDiv.onmousedown = function(){dragstart(this)};
	
	if (wordsOrPictures == 1){
		var para = document.createElement("p");
		para.className = "text";
		
		//Insert labelinput if applicable, otherwise use labelname
		if (Qualtrics.SurveyEngine.getEmbeddedData("generating") == 2){
			var node = document.createTextNode(labelList[i].input);
			para.appendChild(node);	
		} else {
			var node = document.createTextNode(labelList[i].name);
			para.appendChild(node);
		}
		
		//Insert labelinput if applicable
		if (Qualtrics.SurveyEngine.getEmbeddedData("generating") == 3){
			var node2 = document.createTextNode(labelList[i].input);
			var br = document.createElement("br");
			para.appendChild(br);
			para.appendChild(node2);
		}		
			
	newDiv.appendChild(para)
	}
	
	//Set pictures if applicable
	if (wordsOrPictures == 2){
	    // opacity 2 not here
		newDiv.style.backgroundImage = 'url("'+link+''+labelList[i].labelnummer+'.jpg")';
	
	newDiv.style.backgroundRepeat = 'no-repeat';
	newDiv.style.backgroundPosition = 'center';
	}
	
	mainwindow.appendChild(newDiv);
}
	
	
var i = 0;

	function addDiv(){
		
	var newDiv = document.createElement("div");
	
	newDiv.id = i;
	

	
	newDiv.style.zIndex = foreground;
	//Color depending on group
	if (labelList[i].marked == 1){
		newDiv.className = "group1Box";
	} else if (labelList[i].marked == 2){
		newDiv.className = "group2Box";
	} else {
		newDiv.className = "box";
	}
	
	newDiv.style.left = (xwindowsize/2) - (1/2)*boxwidth + "px";
	newDiv.style.top = ((ywindowsize - buttonwindowheight - 3)/2) - (1/2)*boxheight + "px";
	
	newDiv.onmousedown = function(){dragstart(this)};
	
	if (wordsOrPictures == 1){
		var para = document.createElement("p");
		para.className = "text";
		
		//Insert labelinput if applicable, otherwise use labelname
		if (Qualtrics.SurveyEngine.getEmbeddedData("generating") == 2){
			var node = document.createTextNode(labelList[i].input);
			para.appendChild(node);	
		} else {
			var node = document.createTextNode(labelList[i].name);
			para.appendChild(node);
		}
			
		//Insert labelinput if applicable
		if (Qualtrics.SurveyEngine.getEmbeddedData("generating") == 3){
			var node2 = document.createTextNode(labelList[i].input);
			var br = document.createElement("br");
			para.appendChild(br);
			para.appendChild(node2);
		}	
		
	newDiv.appendChild(para)
	}
	
	//Set pictures if applicable
	if (wordsOrPictures == 2){
	    //opacity 3
		newDiv.style.backgroundImage = 'url("'+link+''+labelList[i].labelnummer+'.jpg")';
			if (i==19){
		    		newDiv.style.opacity = "0.8"; 
newDiv.style.filter  = 'alpha(opacity=80)'; // IE fallback
		}
	newDiv.style.backgroundRepeat = 'no-repeat';
	newDiv.style.backgroundPosition = 'bottom';
	}

    if (i > 0) {
                     //mainwindow.removeChild(mainwindow.lastElementChild);
                     //mainwindow.lastElementChild.style.display = "block";
                     
                       if (mainwindow.lastElementChild.style.display === "none") {
    mainwindow.lastElementChild.style.display = "block";
  } else {
    mainwindow.lastElementChild.style.display = "none";
  }
                     console.log(mainwindow.lastElementChild.id)

                     console.log("block");
              //      //mainwindow.lastElementChild.remove();//
			  //	 //console.log(i);
                }
                
                console.log(document.getElementById("mainwindow"))
    
//                 document.querySelectorAll(".mainwindow *").forEach((item) => {
  
//     console.log(item.firstChild.id);
  
// });
                
//                 var elems = document.querySelectorAll('#topbarsection li a');

// for (var i = 0, l = elems.length; i < l; i++) {
//     elems[i].setAttribute("target", "_blank");
// }
//          console.log(elems)       
                //var children = mainwindow.getElementById("mainwindow").children;

//var idArr = [];

//for (var i = 0; i < children.length; i++) {
//  idArr.push(children[i].id);
//}




// Step 2: Use getBoundingClientRect() to obtain position and size information
const rect = newDiv.getBoundingClientRect();

// Step 3: Calculate maximum top and left positions
const maxWidth = window.innerWidth - rect.width - 173;  // Maximum left position
const maxHeight = window.innerHeight - rect.height - 130; // Maximum top position


console.log("Maximum Left Position: " + maxWidth);
console.log("Maximum Top Position: " + maxHeight);

Qualtrics.SurveyEngine.setEmbeddedData( 'maxWidth', maxWidth );
Qualtrics.SurveyEngine.setEmbeddedData( 'maxHeight', maxHeight );

//console.log(childs);
console.log("yesyes")
     //newDiv.querySelector(i).style.visibility = "visible";/////hidden

	
	mainwindow.appendChild(newDiv);
		
	i++;

		
	continuebutton.disabled = true;	

	}
	
	function display(){
	    
	    for (var i = 0; i < labelList.length; i++) {
	var newDiv = document.createElement("div");
	
	newDiv.id = i;
	

	
	//Color depending on group
	if (labelList[i].marked == 1){
		newDiv.className = "group1Box";
	} else if (labelList[i].marked == 2){
		newDiv.className = "group2Box";
	} else {
		newDiv.className = "box";
	}
	newDiv.style.left = labelList[i].xcoordinate+"px";
	newDiv.style.top = labelList[i].ycoordinate+"px";
	/*newDiv.style.left = 0+"px";*/
	/*newDiv.style.top = 0+"px";*/
	
	//newDiv.onmousedown = function(){dragstart(this)};
	
	console.log(childs[i].style.left)
	console.log("chids print")
	

	newDiv.style.backgroundImage = 'url("'+link+''+labelList[i].labelnummer+'.jpg")';
	newDiv.style.backgroundRepeat = 'no-repeat';
	//newDiv.style.backgroundPosition = left: childs[i].style.left ; top: childs[i].style.top;
	newDiv.style.backgroundPosition = childs[i].style.left + childs[i].style.top ;
	


	
	
	mainwindow.appendChild(newDiv);
}; 
	   
	}
	
	

function display2(){
    
    		///////////////
// 				var childs = document.getElementById("mainwindow").querySelectorAll(":scope > .box");
//         for (let j = 0; j <= 3; j++) {
    
//               console.log("ohmyg222")
//               //console.log(childs[j].id)
//               //console.log(childs[0].class)
//               console.log(childs[j].style.backgroundImage)
//               console.log(childs[j].style.left)
//               console.log(childs[j].style.top)
// }
		///////////////
			//mainwindow.removeChild(mainwindow.lastElementChild);//////
	
		for (var i = 0; i < 20; i++) {
	var newDiv = document.createElement("div");
	
	 newDiv.id = i;
	

	
			newDiv.style.zIndex = 106;
	//Color depending on group

		newDiv.className = "box";
		
		
		///////////////
				var childs = document.getElementById("mainwindow").querySelectorAll(":scope > .box");


// Assuming you have a reference to the element
var element = document.getElementById("mainwindow");

// Get the containing element (e.g., the parent if the parent has position: relative)
var container = element.offsetParent;

// Calculate the maximum left and top values
var maxLeft = container.offsetWidth - element.offsetWidth;
var maxTop = container.offsetHeight - element.offsetHeight;





        for (let j = 0; j <= 3; j++) {
    
              console.log("ohmyg222")
              console.log(childs[j].id)
              //console.log(childs[0].class)
              console.log(childs[j].style.backgroundImage)
              console.log(childs[j].style.left)
              console.log(childs[j].style.top)
console.log("Max Left:", maxLeft, "Max Top:", maxTop);
}
		///////////////
	newDiv.style.left = childs[i].style.left;
	newDiv.style.top = childs[i].style.top;
	
	newDiv.onmousedown = function(){dragstart(this)};
	var wordsOrPictures=2
	if (wordsOrPictures == 1){
		var para = document.createElement("p");
		para.className = "text";
		
		//Insert labelinput if applicable, otherwise use labelname
		if (Qualtrics.SurveyEngine.getEmbeddedData("generating") == 2){
			var node = document.createTextNode(labelList[i].input);
			para.appendChild(node);	
		} else {
			var node = document.createTextNode(labelList[i].name);
			para.appendChild(node);
		}
		
		//Insert labelinput if applicable
		if (Qualtrics.SurveyEngine.getEmbeddedData("generating") == 3){
			var node2 = document.createTextNode(labelList[i].input);
			var br = document.createElement("br");
			para.appendChild(br);
			para.appendChild(node2);
		}		
			
	newDiv.appendChild(para)
	}
	
	//Set pictures if applicable
	if (wordsOrPictures == 2){
		newDiv.style.backgroundImage = childs[i].style.backgroundImage;
		newDiv.style.opacity = "0.8"; 
newDiv.style.filter  = 'alpha(opacity=80)'; // IE fallback
	newDiv.style.backgroundRepeat = 'no-repeat';
	newDiv.style.backgroundPosition = 'center';
	}
	
	mainwindow.appendChild(newDiv);
}

}
	function rmdup(){
	    mainwindow.removeChild(mainwindow.lastElementChild);
	}
	
		
	}		
		


});
