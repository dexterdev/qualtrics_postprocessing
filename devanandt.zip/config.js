Qualtrics.SurveyEngine.addOnload(function(){
var that = this;
	
	/*Place Your Javascript Below This Line*/
	
//////////////////////////////// Change variables BELOW this line /////////////////////////////////
	
//1. Changing identity of targets	
	
var pool1 = [
/* Copy the identities of Pool 1's targets into here */
"1.jpg",
"2.jpg",
"3.jpg",
"4.jpg",
"5.jpg",
"6.jpg",
"7.jpg",
"8.jpg",
"9.jpg",
"10.jpg"
];

var pool2 = [
/* Copy the identities of Pool 2's targets into here */
"11.jpg",
"12.jpg",
"13.jpg",
"14.jpg",
"15.jpg",
"16.jpg",
"17.jpg",
"18.jpg",
"19.jpg",
"20.jpg"
];

var pool3 = [
/* Copy the identities of Pool 3's targets into here */
"21.jpg",
"22.jpg",
"23.jpg",
"24.jpg",
"25.jpg",
"26.jpg",
"27.jpg",
"28.jpg",
"29.jpg",
"30.jpg"
];

var pool4 = [
/* Copy the identities of Pool 4's targets into here */
"31.jpg",
"32.jpg",
"33.jpg",
"34.jpg",
"35.jpg",
"36.jpg",
"37.jpg",
"38.jpg",
"39.jpg",
"40.jpg"
];

var pool5 = [
/* Copy the identities of Pool 5's targets into here */
"41.jpg",
"42.jpg",
"43.jpg",
"44.jpg",
"45.jpg",
"46.jpg",
"47.jpg",
"48.jpg",
"49.jpg",
"50.jpg"
];

var pool6 = [
/* Copy the identities of Pool 6's targets into here */
"51.jpg",
"52.jpg",
"53.jpg",
"54.jpg",
"55.jpg",
"56.jpg",
"57.jpg",
"58.jpg",
"59.jpg",
"60.jpg"
];

var pool7 = [
/* Copy the identities of Pool 7's targets into here */
"61.jpg",
"62.jpg",
"63.jpg",
"64.jpg",
"65.jpg",
"66.jpg",
"67.jpg",
"68.jpg",
"69.jpg",
"70.jpg"
];

var pool8 = [
/* Copy the identities of Pool 8's targets into here */
"71.jpg",
"72.jpg",
"73.jpg",
"74.jpg",
"75.jpg",
"76.jpg",
"77.jpg",
"78.jpg",
"79.jpg",
"80.jpg"
];

var pool9 = [
/* Copy the identities of Pool 9's targets into here */
"81.jpg",
"82.jpg",
"83.jpg",
"84.jpg",
"85.jpg",
"86.jpg",
"87.jpg",
"88.jpg",
"89.jpg",
"90.jpg"
];

var pool10 = [
/* Copy the identities of Pool 10's targets into here */
"91.jpg",
"92.jpg",
"93.jpg",
"94.jpg",
"95.jpg",
"96.jpg"
];			
	
//2. Changing number of targets	
	
//Maximum possible number of targets
var maxlabels = 96
Qualtrics.SurveyEngine.setEmbeddedData("maxlabels", maxlabels);	
	
//Number of targets to be presented
var labelnumber = 20;//20
Qualtrics.SurveyEngine.setEmbeddedData("labelnumber", labelnumber);
Qualtrics.SurveyEngine.setEmbeddedData("objectsselectedtotal", labelnumber);
	
//Number of targets to be drawn from pool1
var pool1number = 2

//Number of targets to be drawn from pool2
var pool2number = 2	

//Number of targets to be drawn from pool3
var pool3number = 2;	

//Number of targets to be drawn from pool4
var pool4number = 2;	

//Number of targets to be drawn from pool5
var pool5number = 2;	

//Number of targets to be drawn from pool6
var pool6number = 2;	

//Number of targets to be drawn from pool7
var pool7number = 2;	

//Number of targets to be drawn from pool8
var pool8number = 2;	

//Number of targets to be drawn from pool9
var pool9number = 2;	

//Number of targets to be drawn from pool10
var pool10number = 2;	

//3. Changing appearance of targets	

//Targetwidth in pixels (needs to match with value in "Look and Feel" --> "Advanced" --> "+ Add Custom CSS")
var boxwidth = 173;//173
//	var boxwidth = 567;
Qualtrics.SurveyEngine.setEmbeddedData("boxwidth", boxwidth);
	
//Targetlheight in pixels (needs to match with value in "Look and Feel" --> "Advanced" --> "+ Add Custom CSS")
var boxheight = 130;//130
//	var boxheight = 686;
Qualtrics.SurveyEngine.setEmbeddedData("boxheight", boxheight);

//Targetbordersize in pixels (needs to match with value in "Look and Feel" --> "Advanced" --> "+ Add Custom CSS")
var boxbordersize = 2;
Qualtrics.SurveyEngine.setEmbeddedData("boxbordersize", boxbordersize);

//Horizontal spacing between targets in pixels
var horizontalspacing = 2;
Qualtrics.SurveyEngine.setEmbeddedData("horizontalspacing", horizontalspacing);	

//Vertical spacing between targets in pixels
var verticalspacing = 1;
Qualtrics.SurveyEngine.setEmbeddedData("verticalspacing", verticalspacing);	

//To change the target boxes' border and background color and the targets' font (style, size, color etc.), 
//... in project "Q-SpAM" click "Look and Feel" --> "Advanced" --> "+ Add Custom CSS" 
//... and modify ".box", ".boxClicked", and / or ".text"
	
//To change target boxes' initial location (i.e., number of target columns and rows), 
//... in project "Q-SpAM" click “JS” in the “Spatial arrangement” question of the “Spatial arrangement” block
//... and modify "//Number of columns [...]" (number of rows is = number of targets / number of columns)
	
//Display as block or as sequence (1=block, 2=sequence)
var blockOrSequence = 2;
Qualtrics.SurveyEngine.setEmbeddedData("blockOrSequence", blockOrSequence);

//4. Self-(de)selecting targets from a list
	
// Self-selecting or self-deselecting targets (0=no self-selecting, 1=self-selecting, 2=self-deselecting)
var selecting = 0;
Qualtrics.SurveyEngine.setEmbeddedData("selecting", selecting);	
	
//5. Self-generating targets based on a list
	
//(0=no self-generation, 1=only cues, 2=only self-generated targets, 3=both cues and self-generated targets)
var generating = 0;
Qualtrics.SurveyEngine.setEmbeddedData("generating", generating);

//6. Self-marking targets in a list
	
//Marking (0=no marking, 1=mark <= x in one color, 2=mark >=x in one color, 3=mark exactly x in one color, 4=mark <= x in both colors, 5=mark >=x in both colors, 6=mark exactly x in both colors)
var marking = 0;
Qualtrics.SurveyEngine.setEmbeddedData("marking", marking);
	
//6. Changing background of spatial arrangement slide
	
//Background (0=blank, 1=coordinate axes, 2=coordinate circles)
var background = 1;
Qualtrics.SurveyEngine.setEmbeddedData("background", background);
	
//7. Spatial arrangement of images instead of words 	

//Words or images as stimuli (1=words, 2=images)
var wordsOrPictures = 2;
Qualtrics.SurveyEngine.setEmbeddedData("wordsOrPictures", wordsOrPictures);
	
//Link to directory containing pictures
//var pictureLink = "https://raw.githubusercontent.com/dexterdev/NN2_DISFA_images/main/173_130_renamed/";
var pictureLink = "https://dexterdev.github.io/assets/img/captured";
//var pictureLink = "https://www.mei-raanana.co.il/sites/default/files/styles/threshold-1382/public/wysiwyg_uploads/";
Qualtrics.SurveyEngine.setEmbeddedData("pictureLink", pictureLink);

//////////////////////////////// Change variables ABOVE this line /////////////////////////////////
	
	
var allnumbers = [
pool1number,
pool2number,
pool3number,
pool4number,
pool5number,
pool6number,
pool7number,
pool8number,
pool9number,
pool10number
];	

var allpools= [
pool1,
pool2,
pool3,
pool4,
pool5,
pool6,
pool7,
pool8,
pool9,
pool10
];
	
var pool1length = pool1.length;
var pool2length = pool2.length;
var pool3length = pool3.length;
var pool4length = pool4.length;
var pool5length = pool5.length;
var pool6length = pool6.length;
var pool7length = pool7.length;
var pool8length = pool8.length;
var pool9length = pool9.length;
var pool10length = pool10.length;

var allpoolslength = [
pool1length,
pool2length,
pool3length,
pool4length,
pool5length,
pool6length,
pool7length,
pool8length,
pool9length,
pool10length
];	
	

	
var labelcounter = 1;

	for (var i = 0; i < allpools.length; i++){
		for (var j = 0; j < allpoolslength[i]; j++){
			allpools[i].push({
			name: allpools[i][j],
			labelnummer: labelcounter
			});
		labelcounter++;
		}
	allpools[i].splice(0,allpools[i].length/2);
	}

	
	
for (var i = 0; i < allpools.length; i++){
	shuffle(allpools[i]);
}



var inhalt = [];
	for (var i = 0; i < allpools.length; i++){
		for (var j = 0; j < allnumbers[i]; j++){
			inhalt.push({
				name: allpools[i][j].name,
				labelnummer: allpools[i][j].labelnummer
			});
					
		}

	}	



	
	
	
// Fisher-Yates shuffle

function shuffle(array) {
  var currentIndex = array.length, temporaryValue, randomIndex ;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
}

shuffle(inhalt);
	
var labelList = [];

for (var i = 0; i < labelnumber; i++) {
	labelList.push({
			name: inhalt[i].name,
			labelnummer: inhalt[i].labelnummer,
		});
}

console.log("labelList:");
console.log(labelList);
	
for (var i = 0; i < labelList.length; i++) {
			
			
			Qualtrics.SurveyEngine.setEmbeddedData("label" + labelList[i].labelnummer + "name", labelList[i].name);
			Qualtrics.SurveyEngine.setEmbeddedData("label" + labelList[i].labelnummer + "selected", 1);


		
		}	

		
		
});
